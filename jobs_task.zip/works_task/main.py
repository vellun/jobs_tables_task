from flask import Flask, url_for, render_template, redirect
from data.db_session import global_init
from data.db_session import create_session
from data.users import User, Department
from data.jobs import Jobs
from data import db_session

app = Flask(__name__)
app.config['SECRET_KEY'] = 'yandexlyceum_secret_key'
global_init("db/mars_explorer.db")


@app.route('/<title>')
@app.route('/index/<title>')
def page(title):
    return render_template("base.html", title=title)


@app.route('/')
def works_page():
    db_sess = create_session()
    jobs = db_sess.query(Jobs).all()
    return render_template("works_page.html", jobs=jobs)


if __name__ == '__main__':
    app.run(port=8080, host="127.0.0.1")
